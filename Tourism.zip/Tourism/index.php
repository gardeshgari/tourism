<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>وبسایت گردشگری استان مازندران</title>
    <link href="css/main.css" rel="stylesheet">
    <link href="css/font.css" rel="stylesheet" >
    <link href="css/main.structure.css" rel="stylesheet">
    <link href="css/provisional.css" rel="stylesheet">
    <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/gooey.min.css">
    <link rel="stylesheet" href="css/tooltips.css">
    <link rel="stylesheet" href="css/style.css">

</head>

<body>

<style>
    /*-------- gooey -----*/
    .prettyprint ol.linenums > li {
        list-style-type: decimal;
    }

    /*-------- slider -----*/
    .wrapper {

        width:150px;
        height:300px;

    }

    .text-wrapper {
        position:absolute;
        bottom:0;
        left:0;
        width:100%;
        height:200px;
    }

</style>
<nav id="gooey-h" style="z-index: 10;">
    <input type="checkbox" class="menu-open" name="menu-open2" id="menu-open2"/>
    <label class="open-button" for="menu-open2">
        <span class="burger burger-1"></span>
        <span class="burger burger-2"></span>
        <span class="burger burger-3"></span>
    </label>

    <a class="gooey-menu-item" data-title="هتل ها"> <i class="fa fa-bed"></i> </a>
    <a class="gooey-menu-item" data-title="آثارتاریخی"> <i class="fa fa-bank"></i> </a>
    <a class="gooey-menu-item" data-title="دفاترخدمات مسافرتی"> <i class="fa fa-plane"></i> </a>
    <a class="gooey-menu-item" data-title="فهرست تلفن هتل ها،هتل آپارتمانها ومتل ها"> <i class="fa fa-file"></i> </a>
</nav>
<div class="arrow_box" style="display: none;">
    <p></p>
</div>
<div id="search-box">
    <input id="search-txt" type="text" placeholder="مکان مورد نظر خود را بر روی نقشه بیابید" >
    <span class="search-btn">جستجو</span>
</div>
<div class="wrapper">
    <div class="text-wrapper">
        <div class="cover-body">
            <div class="cover-body-inner">
                <div class="cover-title"> <a href="#" class="link-item title">NOSlideShow.js</a> </div>
                <div class="cover-description">
                    <p>A Background Slideshow Plugin</p>
                    <p class="cover-subtitle"></p>
                </div>
                <div class="cover-actions"> </div>
            </div>
        </div>
    </div>
    <div class="cover-img cover-img__b"></div>
    <div class="cover-img cover-img__a"></div>
</div>
<script src="http://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="js/NOSlideShow.js"></script>
<script src="js/gooey.min.js"></script>
<script src="js/tootletips.js"></script>
<script>
    $('.gooey-menu-item').hover(function () {
         var pos = $(this).position();
         var title = $(this).attr("data-title");
         //alert(title);
         $(".arrow_box p").text(title);
         $(".arrow_box").css({
             "top": pos.top+20,
             "left": "70px",
             "display":"block"
         });
    },function(){
        $(".arrow_box").hide();
    });
/*    $('#hello').click(function () {
        var pos = $(this).position();
        //alert(pos.top);
        $(".arrow_box").css({
            "top": pos.top+25,
            "left": "80px",
            "display":"block"
        });
    });*/
</script>
<script>

    var mySlideShow = new SlideShow('projectSlides');
    mySlideShow.container.label = $(".cover-subtitle");
    mySlideShow.container.image = $(".cover-img.cover-img__a");
    mySlideShow.container.background = $(".cover-img.cover-img__b");

    // Set Slides.
    mySlideShow.setSlides([{name: 'شهرداری بابل', image: './images/d.jpg'},
        {name: 'اردوگاه میرزا کوچک خان رامسر', image: './images/a.jpg'},
        {name: 'جاده نظامی قائمشهر', image: './images/b.jpg'},
        {name: 'فرح آباد ساری', image: './images/c.jpg'}
    ]);

    // Display first slide.
    mySlideShow.displaySlide();

    // Loop slides.
    var showInterval = setInterval("mySlideShow.advanceSlide()", 7000);

    /*
     // Layout
     function adjustCoverImage() {
     var width = $(".cover").width();
     var height = width * 0.50;
     $(".cover").height(height+'px');
     }

     $(window).resize(function() {
     adjustCoverImage();
     });

     $(document).ready(function() {
     adjustCoverImage();
     });*/

</script>
<script>
    $(function($) {
        $("#gooey-h").gooeymenu({
            bgColor: "#68d099",
            contentColor: "white",
            style: "vertical",
            horizontal: {
                menuItemPosition: "glue"
            },
            vertical: {
                menuItemPosition: "spaced",
                direction: "down"
            },
            circle: {
                radius: 90
            },
            margin: "small",
            size: 50,
            bounce: false,
            bounceLength: "small",
            transitionStep: 100,
            hover: "#5dbb89"
        });

    });
</script>
</body>
</html>