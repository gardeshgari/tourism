<!DOCTYPE html>
<html lang="en">
<head>
    <title>jQuery gooey.js Plugin Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/gooey.min.css">

    <script src="http://code.jquery.com/jquery-3.1.1.min.js"></script>
    <script src="js/gooey.min.js"></script>
    <style>
        .prettyprint ol.linenums > li {
            list-style-type: decimal;
        }

        .arrow_box {
            position: relative;
            background: #88b7d5;
            border: 1px solid #c2e1f5;
        }
        .arrow_box:after, .arrow_box:before {
            left: 100%;
            top: 50%;
            border: solid transparent;
            content: " ";
            height: 0;
            width: 0;
            position: absolute;
            pointer-events: none;
        }

        .arrow_box:after {
            border-color: rgba(136, 183, 213, 0);
            border-left-color: #88b7d5;
            border-width: 10px;
            margin-top: -10px;
        }
        .arrow_box:before {
            border-color: rgba(194, 225, 245, 0);
            border-left-color: #c2e1f5;
            border-width: 11px;
            margin-top: -11px;
        }
    </style>
</head>
<body>

<script>
    $(function($) {
        $("#gooey-h").gooeymenu({
            bgColor: "#68d099",
            contentColor: "white",
            style: "vertical",
            horizontal: {
                menuItemPosition: "glue"
            },
            vertical: {
                menuItemPosition: "spaced",
                direction: "down"
            },
            circle: {
                radius: 90
            },
            margin: "small",
            size: 80,
            bounce: true,
            bounceLength: "small",
            transitionStep: 100,
            hover: "#5dbb89"
        });

    });
</script>


<nav id="gooey-h">
    <input type="checkbox" class="menu-open" name="menu-open2" id="menu-open2"/>
    <label class="open-button" for="menu-open2">
        <span class="burger burger-1"></span>
        <span class="burger burger-2"></span>
        <span class="burger burger-3"></span>
    </label>

    <a href="#" class="gooey-menu-item"> <i class="fa fa-train"></i> </a>
    <a href="#" class="gooey-menu-item"> <i class="fa fa-bicycle"></i> </a>
    <a href="#" class="gooey-menu-item"> <i class="fa fa-rocket"></i> </a>
    <a href="#" class="gooey-menu-item"> <i class="fa fa-automobile"></i> </a>
</nav>

    <div class="arrow_box">
        <p>salam</p>
    </div>

</body>
</html>